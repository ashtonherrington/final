#ifndef SWITCH_ROOM
#define SWITCH_ROOM

#include "humanoids.h"
#include <iostream>
#include "room.h"
#include <string>
using std::string;

class switch_room : public room {

   private:
      bool switch_flipped;
      int room_to_change;
      bool visited;

   public:
      switch_room(int a, int b, string c): room(a, b, c){
         switch_flipped = false;
         visited = false; 
      }
      void room_event(); //entering this room offers a menu to fight or run away from the monster
      void room_event2(); //the player is given menu options as to how to proceed
      string getName();
      bool getSwitch();
      int getRoomToChange();
      void isVisited(){visited = true;};
      bool getVisited(){ return visited;};
};

#endif
