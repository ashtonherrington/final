#ifndef TELEPORT_ROOM
#define TELEPORT_ROOM

#include "humanoids.h"
#include "room.h"
#include <string>
#include <iostream>

using std::endl;
using std::cout;
using std::cin;
using std::string;

class teleport_room: public room{

   private:
      room *farAway;
      int orbChoice;

   public:
      teleport_room(int a, int b, string c) : room(a, b, c){
      }
      void room_event();
      void room_event2();
      string getName(){};
      room* getFarAway();
      void setFarAway(room *a);
      int getChoice(){return orbChoice;};
};

#endif
