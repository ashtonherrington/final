#include <iostream> //include iostream library
#include <vector> //include vector library
#include <fstream> //include file stream library
#include <string> //include string library
#include <cstddef> //include library for NULL use
#include "room.h" //include room header
#include "normal_room.h" //include normal room header
#include "switch_room.h" //include switch room header
#include "monster_room.h" //include monster room header
#include "item_room.h" //include item room header
#include "teleport_room.h" //include the teleport room header
#include "humanoids.h" //include humanoids header
#include "player.h" //include player header
#include "monster.h" //include monster header

//common used terms
using std::string;
using std::vector;
using std::cin;
using std::cout;
using std::endl;
using std::ifstream;

//fuction prototype for moving a room, accepts a reference to the player as its sole parameter
int move_rooms(player* a, vector<vector<room*>> maze);

int main(){
  
  int movement_counter = 0; //accumulator for number of room transitions the player makes
   
  cout << string(100, '\n');

  ifstream input("setup.txt", std::ios::in); //the input file stream is opened to provide each room with its type number

  if(!input){ //if it does not open
     cout << "Error opening input file." << endl; //then an error message appears
     exit(1); //and program is shut down
  }

  vector<vector<room*>> maze; //a matrix of pointers rooms   

  vector<room*> row1;
  room* temp_1 = new item_room(0, 0, "item", "TORCH");
  row1.push_back(temp_1);

  room* temp_2 = new teleport_room(0, 1, "teleport");
  row1.push_back(temp_2);
  
  room* temp_3 = new monster_room(0, 2, "monster", "BLOOD GOLEM", 20, 6, 6, 4, 2, 3);
  row1.push_back(temp_3);
  
  room* temp_4 = new normal_room(0, 3, "normal");
  row1.push_back(temp_4);
  maze.push_back(row1);


  vector<room*> row2;
  room* temp_5 = new normal_room(1, 0, "normal");
  row2.push_back(temp_5);

  room* temp_6 = new monster_room(1, 1, "monster", "LIVING ARMOR", 20, 6, 6, 4, 2, 3);
  row2.push_back(temp_6);
  
  room* temp_7 = new normal_room(1, 2, "normal");
  row2.push_back(temp_7);
  
  room* temp_8 = new monster_room(1, 3, "monster", "VAMPIRE", 20, 6, 6, 8, 2, 3);
  row2.push_back(temp_8);
  maze.push_back(row2);


  vector<room*> row3;
  room* temp_9 = new switch_room(2, 0, "switch");
  row3.push_back(temp_9);

  room* temp_10 = new item_room(2, 1, "item", "SHIELD");
  row3.push_back(temp_10);
  
  room* temp_11 = new switch_room(2, 2, "switch");
  row3.push_back(temp_11);
  
  room* temp_12 = new normal_room(2, 3, "normal");
  row3.push_back(temp_12);
  maze.push_back(row3);
 
 
  vector<room*> row4;
  room* temp_13 = new normal_room(3, 0, "normal");
  row4.push_back(temp_13);

  room* temp_14 = new normal_room(3, 1, "normal");
  row4.push_back(temp_14);
  
  room* temp_15 = new normal_room(3, 2, "normal");
  row4.push_back(temp_15);
  
  room* temp_16 = new teleport_room(3, 3, "teleport");
  row4.push_back(temp_16);
  maze.push_back(row4);


  vector<room*> row5;
  room* temp_17 = new item_room(4, 0, "item", "SWORD");
  row5.push_back(temp_17);

  room* temp_18 = new normal_room(4, 1, "normal");
  row5.push_back(temp_18);
  
  room* temp_19 = new monster_room(4, 2, "monster", "SKELETON", 20, 6, 6, 2, 1, 3);
  row5.push_back(temp_19);
  
  room* temp_20 = new switch_room(4, 3, "switch");
  row5.push_back(temp_20);
  maze.push_back(row5);

  int storage; //this holds the interger (for room types) from the input file stream

  for(int i=0; i<5; i++){ //for some reason the code seg faults without 2 extra nested sets of for loops cannot figure out for life of me
     for(int j=0; j<4; j++){ //inner for loop cycles through
        input >> storage; //input feeds in to storage
	maze[i][j]->set_type(storage); //the maze at this point it set equal to this type 
     }
  } 
  
  for(int i=0; i<5; i++){ //cycles through Y coordinates
     for(int j=0; j<4; j++){ //cycles through X  coordinates
	//if the room is of any of the following types (rooms that have north rooms adjacent) then their north pointer it set to that room
	if(maze[i][j]->get_type() == 1 || maze[i][j]->get_type() == 5 || maze[i][j]->get_type() == 6 || maze[i][j]->get_type() == 7 || maze[i][j]->get_type() == 11
	      || maze[i][j]->get_type() == 12 || maze[i][j]->get_type() == 13 || maze[i][j]->get_type() == 15){
	   maze[i][j]->setNorth(maze[i-1][j]);	
     	}
	else{
	   maze[i][j]->setNorth(NULL);
	}
	//if the room is of any of the following types (rooms that have west rooms adjacent) then their west pointer is set to that room
	if(maze[i][j]->get_type() == 3 || maze[i][j]->get_type() == 6 || maze[i][j]->get_type() == 8 || maze[i][j]->get_type() == 10 || maze[i][j]->get_type() == 12
   	      || maze[i][j]->get_type() == 13 || maze[i][j]->get_type() == 14 || maze[i][j]->get_type() == 15){
   	  
	   maze[i][j]->setWest(maze[i][j]);	
	}
	else{
	   maze[i][j]->setWest(NULL);
	}
	//if the room is of any of the following types (rooms that have south rooms adjacent) then their south pointer is set equal to that room
        if(maze[i][j]->get_type() == 2 || maze[i][j]->get_type() == 5 || maze[i][j]->get_type() == 8 || maze[i][j]->get_type() == 9 || maze[i][j]->get_type() == 11
	      || maze[i][j]->get_type() == 12 || maze[i][j]->get_type() == 14 || maze[i][j]->get_type() == 15){
	   maze[i][j]->setSouth(maze[i+1][j]);	
	}
        else{
	   maze[i][j]->setSouth(NULL);
	}
	//if the room is of any of the fllowing types (rooms that have east rooms adjacent) then their east pointer is set equal to that room
        if(maze[i][j]->get_type() == 4 || maze[i][j]->get_type() == 7 || maze[i][j]->get_type() == 9 || maze[i][j]->get_type() == 10 || maze[i][j]->get_type() == 11
	      || maze[i][j]->get_type() == 13 || maze[i][j]->get_type() == 14 || maze[i][j]->get_type() == 15){
	   maze[i][j]->setEast(maze[i][j+1]);	
        }
	else{
	   maze[i][j]->setEast(NULL);
	}
     }
  }

  player* maze_runner; //the player is declared
  
  maze_runner = new player();

  maze_runner->setLocation(maze[4][1]); //the player's initial location is set to the room at X coordinate 2 Y coordinate 5

  bool game_ends = false; //boolean controls below do while loop of the player winning of quitting
  int movement_choice; //int to hold movement choice selection
  bool into_black;

  do{ //this runs as long as the game has not ended
 
     into_black = false;   
     cout << string(4, '\n');
     //statement informs the user of their current location
     
     //if the user is at the exit, they win!
     if(maze_runner->getLocation() == maze[0][3]){
      
	cout << "YOU HAVE DISCOVERED THE EXIT!" << endl;
        cout << "THE GAME IS OVER, YOU HAVE WON!!!" << endl << endl;
        cout << "It took you " << movement_counter << " turns to find the exit." << endl;
	cin.get();
        exit(0);   
     }
     
     //function call to move rooms using maze_runner as parameter, saved in movement choice variable
     movement_choice = move_rooms(maze_runner, maze);  

     if(movement_choice != 2 && maze_runner->hasTorch() == false && maze_runner->getLocation() ==  maze[1][2]){
        cout << "\nYou stumble and fall in the darkness." << endl;
	cout << "You have died, respawning at the beginning of the dungeon" << endl;
	cout << "\nPress enter to continue." << endl;
	cin.ignore(100, '\n');
	cin.get();
	into_black = true;
	maze_runner->setLocation(maze[4][1]);
     }

     if(movement_choice == 1 && into_black == false){ //if they choose 1
    	movement_counter++;
	int current_x;
       	int current_y;
	current_x =  maze_runner->getLocation()->get_x();
	current_y = maze_runner->getLocation()->get_y();
	maze_runner->setLocation(maze[current_y-1][current_x]); //the player's location is set equal to the room north of them
     }

     if(movement_choice == 2 && into_black == false){ //if they choose 2
    	movement_counter++;
       	int current_x;
	int current_y;
       	current_x =  maze_runner->getLocation()->get_x();
	current_y = maze_runner->getLocation()->get_y();
        maze_runner->setLocation(maze[current_y][current_x-1]); //the player's location is set equal to the room north of them
     }

     if(movement_choice == 3 && into_black == false){ //if they choose 3
    	movement_counter++;
      	int current_x;
	int current_y;
       	current_x =  maze_runner->getLocation()->get_x();
	current_y = maze_runner->getLocation()->get_y();
        maze_runner->setLocation(maze[current_y+1][current_x]); //the player's location is set equal to the room north of them
     }     
	
     if(movement_choice == 4 && into_black == false){ //if they choose 4
    	movement_counter++;
       	int current_x;
       	int current_y;
	current_x =  maze_runner->getLocation()->get_x();
	current_y = maze_runner->getLocation()->get_y();
        maze_runner->setLocation(maze[current_y][current_x+1]); //the player's location is set equal to the room north of them
     }  
     
     cout << string(100, '\n');

     if(movement_counter == 6)
	cout << "THE CLOCK STRIKES FIVE." << endl;
     if(movement_counter == 12)
	cout << "THE CLOCK STRIKES SIX." << endl;
     if(movement_counter == 18)
	cout << "THE CLOCK STRIKES SEVEN" << endl;
     if(movement_counter == 24)
	cout << "THE CLOCK STRIKES EIGHT." << endl;
     if(movement_counter == 30)
	cout << "THE CLOCK STRIKES NINE." << endl;
     if(movement_counter == 36)
	cout << "THE CLOCK STRIKES TEN." << endl;
     if(movement_counter == 42)
	cout << "THE CLOCK STRIKES ELEVEN." << endl;
     if(movement_counter >= 48){
        cout << "\nTHE CLOCK STRIKES MIDNIGHT, YOU ARE OUT OF TIME..." << endl;
	cout << "YOU HAVE LOST. GAME OVER MAN, GAME OVER."  << endl;
	exit(0);     
     }

  }while(game_ends == false); //this should never occur, game only ends if player finds the exit
  
  return 0; //program ends
}

//this function is designed to take the pointer to the player as a parameter, and move them to their new location
int move_rooms(player* a, vector<vector<room*>> maze){

  int direction; //int variable to store direction they choose to move
  bool valid_move; //bool to ensure they  can actually move the way they choose
  int battle_outcome;
  bool new_to_room = true;
  string found_item;
  bool falls = false;

  do{ //QC loop doesn't stop if they choose a bad selection
     
     if(a->getLocation()->getTypeName() == "normal"){
        normal_room* temp = static_cast<normal_room*>(a->getLocation());
        if(temp->getVisited() == false){ 
	   temp->room_event();
	   temp->isVisited();
	}
	else
	   temp->room_event2();
     }


     if(a->getLocation()->getTypeName() == "teleport"){
        teleport_room* temp = static_cast<teleport_room*>(a->getLocation());
	temp->room_event();
        if(temp->getChoice() == 1 && temp->get_y() == 0)
	   a->setLocation(maze[3][3]);  
        if(temp->getChoice() == 1 && temp->get_y() == 3)
	   a->setLocation(maze[0][1]);
     }


     if(a->getLocation()->getTypeName() == "switch"){
        switch_room* temp = static_cast<switch_room*>(a->getLocation());
        if(temp->getSwitch() == false)
	   temp->room_event();

	if(temp->getSwitch() == true){
           if(temp->getRoomToChange() == 18){ 	
	      cout << "\nYou hear a sound in the distance." << endl;
	      cout << "Perhaps a new path is available to you..." << endl;
	      cout << "\nPress enter to continue.";
	      cin.ignore(1000, '\n');
	      cin.get();
	      maze[4][1]->set_type(13);
	      maze[4][1]->setNorth(maze[3][1]);
	      maze[3][1]->set_type(12);
	      maze[3][1]->setSouth(maze[4][1]);
	   }
	   if(temp->getRoomToChange() == 16){
	      cout << "\nYou hear a sound in the distance." << endl;
	      cout << "Perhaps a new path is available to you..." << endl;
	      cout << "\nPress enter to continue.";
	      cin.ignore(1000, '\n');
	      cin.get();
	      maze[3][3]->set_type(6);
	      maze[3][3]->setNorth(maze[2][3]);
	      maze[2][3]->set_type(5);
	      maze[2][3]->setSouth(maze[3][3]);
	   }
	   if(temp->getRoomToChange() == 9 && temp->getVisited() == true){
             cout << "Warily eying the room ahead of you, you decide to take a step back." << endl;
	     cout << "\nPress enter to continue.";
	     falls = true;
	     cin.ignore(1000, '\n');
	     cin.get();
	     a->setLocation(maze[3][0]);     
	     cout << string(100, '\n');
             cout << "Bones scatter the floor, there appear to be teeth mark on them." << endl; 
	   }
	   if(temp->getRoomToChange() == 9 && temp->getVisited() == false){
	     cout << string(100, '\n');
	     cout << "\nSuddenly the floor falls out from under you, as you fall, you notice bloody fingerprints on the wall next to the switch...too late." << endl;
	     cout << "You have died, respawning at the dungeon entrance." << endl;
	     temp->isVisited();
	     a->setLocation(maze[4][1]);
	     cout << "\nPress enter to continue.";
	     cin.ignore(1000, '\n');
	     cin.get();
	     cout << string(100, '\n');
	     falls = true;
	     cout << "You awake disoriented, feeling like you've been here before." << endl;
	   }
     	}
	
	if(falls == false){
	   cout << string(100, '\n');
	   temp->room_event2();
	}
     }

     if(a->getLocation()->getTypeName() == "item"){
        item_room* temp = static_cast<item_room*>(a->getLocation());
        if(temp->getFound() == false)	
     	   temp->room_event();
        else
	   temp->room_event2();
     }

     if(a->getLocation()->getTypeName() == "monster"){
        monster_room* temp = static_cast<monster_room*>(a->getLocation());
	if(temp->getIsAlive() == true){
	   temp->room_event();
	   if(a->hasRing() == true){
	      temp->monsterReturn()->hamstring();
	   }
	   battle_outcome = temp->do_battle(a, temp->monsterReturn());
	   if(battle_outcome == 1){
	      if(temp->get_y() == 0){
	         cout << "YOU FIND A RING OF PROTECTION ON THE CORPSE OF THE GOLEM!" << endl;
		 a->findsRing();
	         if(a->hasTorch() == true && a->hasShield() == true && a->hasSword() == true && a->hasRing() == true)
	            cout << "\nYOUR BAG IS NOW FULL.\n" << endl;
	      }
	      a->refresh();
	      temp->setIsAlive(false);
	   }
           if(battle_outcome == 0){
              temp->monsterReturn()->refresh();
	      a->refresh();
	      a->setLocation(maze[4][1]);
           }
	   cout << "Press enter to continue.";
	   cin.get();
	   cout << string(100, '\n');
	   cout << "Your sanity dwindles. This can't be happening." << endl;
	}
        else
	   temp->room_event2();
     }
     
     cout << string(2, '\n');

     valid_move = true; //bool to ensure they  can actually move the way they choose

     //if the type of room is one of the types listed here, it has a north neighbor
     if(a->getLocation()->get_type() == 1 || a->getLocation()->get_type() == 5 || a->getLocation()->get_type() == 6 || a->getLocation()->get_type() == 7 || a->getLocation()->get_type() == 11
	   || a->getLocation()->get_type() == 12 || a->getLocation()->get_type() == 13 || a->getLocation()->get_type() == 15){
     
	cout << "1. Move North." << endl; //and in response the player is offered the choice to move north
     }
     else //otherwise, they are informed of the wall to their north
	cout << "There is a wall to your North." << endl;
     
     //if the type of room is one of the types listed here, it has a west neighbor
     if(a->getLocation()->get_type() == 3 || a->getLocation()->get_type() == 6 || a->getLocation()->get_type() == 8 || a->getLocation()->get_type() == 10 || a->getLocation()->get_type() == 12
	   || a->getLocation()->get_type() == 13 || a->getLocation()->get_type() == 14 || a->getLocation()->get_type() == 15){
     
	cout << "2. Move West." << endl; //and in response the player is offered the choice to move west
     }
     else //otherwise they are informed of the wall to their west
	cout << "There is a wall to your West." << endl;
   
     //if the type of room is one of the types listed here, it has a south neighbor
     if(a->getLocation()->get_type() == 2 || a->getLocation()->get_type() == 5 || a->getLocation()->get_type() == 8 || a->getLocation()->get_type() == 9 || a->getLocation()->get_type() == 11
	   || a->getLocation()->get_type() == 12 || a->getLocation()->get_type() == 14 || a->getLocation()->get_type() == 15){
     
	cout << "3. Move South." << endl; //and in response the player is offered the choice to move south
     }
     else // otherwise they are informed of the wall to their south
	cout << "There is a wall to your South." << endl;

     //if the type of room is one of the types listed here, it has a east neighbor
     if(a->getLocation()->get_type() == 4 || a->getLocation()->get_type() == 7 || a->getLocation()->get_type() == 9 || a->getLocation()->get_type() == 10 || a->getLocation()->get_type() == 11
	   || a->getLocation()->get_type() == 13 || a->getLocation()->get_type() == 14 || a->getLocation()->get_type() == 15){
     
	cout << "4. Move East." << endl; //and in response the player is offered the choice to move east
     }
     else //otherwise they are informed of the wall to their east
	cout << "There is a wall to your East." << endl;
     
     cout << "5. Search/interact with the room." << endl;     
    
     cout << "\n\nPlease choose your action now: ";

     //while loop ensures the player enters an integer between 1-4
     while(!(cin>>direction) || direction <1 || direction > 5){
	cin.clear();//flags cleared
	cin.ignore(1000, '\n'); //buffer cleared
	new_to_room = false;
	cout << "Please enter a valid menu selection 1-5: ";//player re-prompted
     }

     if(direction == 1 && a->getLocation()->getNorth() == NULL){ //if the player tries to walk in a direction not pointed to by the current room
        cout << "\nYou cannot move this direction." << endl; //they run in to a wall and get called a dummy
	valid_move = false; //valid_move is set to false
        new_to_room = false;
     }

     if(direction == 2 && a->getLocation()->getWest() == NULL){ //if the player tries to walk in a direction not pointed to by the current room
        cout << "\nYou cannot move this direction." << endl; //they run in to a wall and get called a dummy
	valid_move = false; //valid_move is set to false
        new_to_room = false;
     }

     if(direction == 3 && a->getLocation()->getSouth() == NULL){ //if the player tries to walk in a direction not pointed to by the current room
        cout << "\nYou cannot move this direction." << endl; //they run in to a wall and get called a dummy
	valid_move = false; //valid_move is set to false
        new_to_room = false;
     }

     if(direction == 4 && a->getLocation()->getEast() == NULL){ //if the player tries to walk in a direction not pointed to by  the current room
        cout << "\nYou cannot move this direction." << endl; //they run in to a wall and get called a dummy
	valid_move = false; //valid_move is set to false
        new_to_room = false;
     }

     if(direction == 5){
	if(a->getLocation()->getTypeName() == "item"){
	   item_room* temp = static_cast<item_room*>(a->getLocation());
           if(temp->getFound() == false){
	      temp->finds();
	      found_item = temp->getItem();       
	      cout << "\nYOU HAVE FOUND THE " << found_item << "!!!" << endl;
	      if(found_item == "SWORD"){
	         a->findsSword();
		 a->setADiceNum(4);
	      }
	      if(found_item == "SHIELD"){
                 a->findsShield();
		 a->setDDiceNum(4);		 
	      }
	      if(found_item == "TORCH"){
	        a->findsTorch();
	      }
	      if(a->hasTorch() == true && a->hasShield() == true && a->hasSword() == true && a->hasRing() == true)
	         cout << "YOUR BAG IS NOW FULL." << endl;
	   }
	   else
	      cout << "\nNOTHING TO FIND HERE." << endl;
	}
	else{
	   cout << "\nNOTHING TO FIND HERE." << endl;
	}

        cout << "\nPress enter to continue.";
        cin.ignore(1000, '\n');
        cin.get();
        cout << string(100, '\n');
     }
      
  }while(valid_move == false); //if valid_move is false this re-runs
  
  return direction; //function returns direction chosen
}
