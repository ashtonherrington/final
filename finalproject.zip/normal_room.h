#ifndef NORM_ROOM
#define NORM_ROOM

#include "humanoids.h"
#include "room.h"
#include <string>
#include <iostream>

using std::endl;
using std::cout;
using std::cin;
using std::string;

class normal_room: public room{

   private:
      bool visited;

   public:
      normal_room(int a, int b, string c) : room(a, b, c){
      visited = false;
      }
      void room_event(); //event that occurs in the room, makes room pure virtual
      void room_event2(); //event that occurs in the room, makes room pure virtual
      string getName(){};
      void isVisited(){visited = true;};
      bool getVisited(){ return visited;};
};

#endif
