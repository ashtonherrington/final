#ifndef ITEM_ROOM
#define ITEM ROOM

#include "humanoids.h"
#include "room.h"
#include <string>
#include <iostream>

using std::endl;
using std::cout;
using std::cin;
using std::string;

class item_room : public room{

   private:
      string item;
      bool isFound;

   public:
      item_room(int a, int b, string c, string item) : room(a,b,c){
         this->item = item;    
         isFound = false;	 
      }
      void room_event();
      void room_event2();
      string getName(){};
      string getItem();
      void finds(){isFound = true;};
      bool getFound(){return isFound;};
};

#endif
