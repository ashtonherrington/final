#ifndef MONSTER_ROOM
#define MONSTER_ROOM

#include <iostream>
#include "humanoids.h"
#include "monster.h"
#include "room.h"
#include <string>
using std::string;

class monster_room : public room {

   private:
      humanoids* enemy;
      string monster_name;
      bool monster_alive;

   public:
      monster_room(int a, int b, string c, string name, int HP, int ADT, int DDT, int ADN, int DDN, int armor): room(a, b, c){
         monster_name = name;
	 enemy = new monster(name, HP, ADT, DDT, ADN, DDN, armor);
         monster_alive = true;
      }
      void room_event(); //entering this room offers a menu to fight or run away from the monster
      void room_event2(); //the player is given menu options as to how to proceed
      int do_battle(humanoids* a, humanoids* b);      
      string getName();
      bool getIsAlive();
      void setIsAlive(bool a);
      humanoids* monsterReturn();
};

#endif
