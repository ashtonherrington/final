#include "item_room.h"

void item_room::room_event(){

   if(x_coord == 0 && y_coord == 4)
      cout << "The floor is covered with bones, you see a glint of metal within a ribcage." << endl;
   
   if(x_coord == 0 && y_coord == 0)
      cout << "Torches illuminate a painting, it appears to be a volcano erupting blood." << endl;

   if(x_coord == 1 && y_coord == 2)
      cout << "A long hallway filled with decorative armor." << endl;

}

void item_room::room_event2(){

   if(x_coord == 0 && y_coord == 4){
      cout << "Something very large is moving beneath the bones. Suddenly, you hear a sickening crunching sound." << endl;
      cout << "Maybe its time to leave?" << endl;
   }
   if(x_coord == 0 && y_coord == 0){
      cout << "With the light diminished, the painting appears to move in the darkness." << endl;
      cout << "The blood appears to actually flow across the canvas." << endl;
   }

   if(x_coord == 1 && y_coord == 2)
      cout << "The remaining pieces of armor in this room do not seem useful." << endl;

}

string item_room::getItem(){
   return item;
}
