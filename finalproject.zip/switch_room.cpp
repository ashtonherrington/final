#include "switch_room.h"

void switch_room::room_event(){
  
   int choice;
   cout << "You observe something on the wall and move close to inspect it." << endl;
   cout << "You see a lever on the wall, what do you do?" << endl << endl;
   cout << "1. Pull down the lever." << endl;
   cout << "2. Leave it alone." << endl << endl;

   cout << "Please choose your selection now: ";

   while(!(cin>>choice) || choice < 1 || choice > 2){
      cin.clear();
      cin.ignore(1000, '\n');
      cout << "Invalid selection, please choose 1 or 2: ";   
   }

   if(choice == 1){
      
      switch_flipped = true;
      
      if(x_coord == 3 && y_coord == 4){
         this->room_to_change = 18;
      }
      if(x_coord == 0 && y_coord == 2){
         this->room_to_change = 9;
      }
      if(x_coord == 2 && y_coord == 2){
         this->room_to_change = 16;
      }
   }
}


void switch_room::room_event2(){

   if(x_coord == 3 && y_coord == 4){
      cout << "You inspect the room containing the switch." << endl;
      cout << "It appears to be an old wine cellar, for some reason the wine casks smell strongly of iron..." << endl;
   
   }
      
   if(x_coord == 0 && y_coord == 2){
      cout << "You inspect the room containing the switch." << endl;
      cout << "Near the lever, you notice bloodly scratches on the wall." << endl;  
   }

   if(x_coord == 2 && y_coord == 2){
      cout << "You inspect the room containing the switch." << endl;
      cout << "The hallway abruptly stops here, despite the sense of doom behind you, you have no choice but to turn around." << endl;
   }
}

string switch_room::getName(){
}

bool switch_room::getSwitch(){
   return switch_flipped;
}

int switch_room::getRoomToChange(){
   return room_to_change;
}
