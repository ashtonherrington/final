#include "teleport_room.h"

void teleport_room::room_event(){
    
   int selection;   
   cout << "A bright purple orb pulsates from the center of the room, calling out to you, what will you do?" << endl;
   cout << "You sense a powerful evil through the orb, make sure you are prepared before continuing." << endl;

   cout << "\n1. Touch the orb." << endl;
   cout << "2. Stay and inspect the room." << endl;
 
   cout << "\nPlease make your selection now: ";
   while(!(cin>>selection) || selection < 1 || selection > 2){
      cin.clear();
      cin.ignore(1000, '\n');
      cout << "Please choose a valid selection: ";
   }
   
   if(selection == 1){
      cout << string(100, '\n');
      cout << "The world fades to black....you reappear in a similar room, but the orb has not moved" << endl;
      orbChoice = 1; 
   } 
      
   else{
      orbChoice = 2;  
      cout << string(100, '\n');
      cout << "The orb calls to you..." << endl;   
   }
}

void teleport_room::room_event2(){

}

room* teleport_room::getFarAway(){
   return farAway;
}

void teleport_room::setFarAway(room* a){
   farAway = a;
}

