#include "Library.h"
#include "Book.h"
#include "Patron.h"
/* *************************************************************************************************
the default constructor for the library
************************************************************************************************* */
Library::Library(){
    currentDate = 0; //current date is initialized to 0
    holdings.reserve(100); //holdings is reserved to 100 subscripts
    members.reserve(100); //members is reserved to 100 subscripts
}
/* *************************************************************************************************
getCurrentDate function allows user access of the library variable currentDate
************************************************************************************************* */
int Library::getCurrentDate(){
    return currentDate;
}
/* *************************************************************************************************
addBook function allows user to add book ID, title and author in, these variables are then used to
create a new book which is then pushed in to the holdings vector of the library
************************************************************************************************* */
void Library::addBook(){

    bool good_ID = true; //goodID set to true to ensure no repeat IDs entered

    cout << "\nPlease enter a new book ID: "; //prompt to enter new book ID

    string temp_book_ID; //temp string variable to hold book ID
    getline (cin, temp_book_ID); //getline acquires as many characters as user enters

    cout << "Please enter the book's title: "; //prompt to enter new book title

    string temp_book_title; //temp string variable to hold book title
    getline (cin, temp_book_title); //getline acquires as many characters as user enters

    cout << "Please enter the book's author: "; //prompt to enter book's author

    string temp_book_author; //temp variable to hold book's author
    getline (cin, temp_book_author); //getline acquires as many characters as user enters

    Book temp_book(temp_book_ID,temp_book_title,temp_book_author); //a book is created with the three variables as parameters

    for (int i=0; i<getLibrarySize(); i++){ //for loop scans the contents of the library holdings vector
        if (temp_book.getIdCode() == getBook(i)->getIdCode()){ //determines if the ID already exists in the library
            cout << "This ID number is already taken."; //if it does, this message appears
            good_ID = false; //and good ID bool is set to false
        }
    }
    if (good_ID == true){ //if the good ID remains true
        cout << "\nNew book successfully entered."; //this informs user the book is being entered
        holdings.push_back(temp_book); //the book is entered in to the holdings vector
    }
    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get(); //user presses enter, gives them time to read the screen before it disappears
}
/* *************************************************************************************************
the addMember function allows the user to enter new members in to the library member database
************************************************************************************************* */
void Library::addMember(){

    bool good_ID = true; //good ID is set to true at the beginning of each function call

    cout << "\nPlease enter a new member ID: "; //user is prompted to enter a user ID

    string temp_mem_id; //temp string variable to hold the user ID
    getline (cin, temp_mem_id); //getline acquires all of the characters the user enters

    cout << "Please enter the member's name: "; //prompt to enter member name

    string temp_mem_name; //temp string to hold the members name
    getline (cin, temp_mem_name); //getline acquires all of the characters the user enters

    Patron temp_patron(temp_mem_id,temp_mem_name); //new patron is created with the ID and name as parameters

    for (int i=0; i<getMembersSize(); i++){ //for loop scans the library's member vector
        if (temp_patron.getIdNum() == getPatron(i)->getIdNum()){ //if any member ID matches the new ID
            cout << "This ID number is already taken."; //it tells the user they have input an invalid member ID
            good_ID = false; //and sets the good ID bool to false
        }
    }
    if (good_ID == true){ //if the good ID remains true after the scan
        cout << "\nNew member successfully entered."; //they are informed that they successfully entered a new user
        members.push_back(temp_patron); //and the new user is pushed back to the members vector
    }
    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get(); //user presses enter

}
/* *************************************************************************************************
incrementDate function allows the user access to the library currentDate variable, and allows them
to call this function to increase said date by 1, it then automatically scans the libraries members
and adds fines for any of their overdue books.
************************************************************************************************* */
void Library::incrementCurrentDate(){

    currentDate++; //current date variable is incremented

    for (int i=0; i< getMembersSize(); i++){ //for loop scans the contents of the library member vector
        double the_accumulator = 0; //at the beginning of each member the accumulator is set to 0
        for (int j=0; j< getLibrarySize(); j++){ //within each member, for loop scans the contents of the library books
            if (getBook(j)->getCheckedOutBy()->getIdNum() == getPatron(i)->getIdNum()){ //if the ID number of the person who checked out a book matches the current member ID number
                if ((getCurrentDate() - getBook(j)->getDateCheckedOut()) > Book::CHECK_OUT_LENGTH){ //then a second if statement determines if the current date minus the checkout date is overdue
                    the_accumulator += ((getCurrentDate() - getBook(j)->getDateCheckedOut()-Book::CHECK_OUT_LENGTH)*(Library::DAILY_FINE)); //if it is overdue, late fine of 0.1 per day is added per book
                }
            }
        }
        getPatron(i)->amendFine(the_accumulator); //the fines the user owes are then amended to their record before next member is scanned
    }
}
/* *************************************************************************************************
this small function is designed to give the user quick access to the library holdings vector size
information
************************************************************************************************* */
int Library::getLibrarySize(){
    return holdings.size();
}
/* *************************************************************************************************
this small function is designed to give the user quick access to the library members vector size
information
************************************************************************************************* */
int Library::getMembersSize(){
    return members.size();
}
/* *************************************************************************************************
getPatron function requires an integer parameter input i, and in return it will return the pointer to
the member class stored at the integer i location with the library members vector
************************************************************************************************* */
Patron* Library::getPatron(int subscript){ //
    Patron* membersPointer = &members[subscript]; //a pointer to a patron is initialized to the address of the members subscript
    return membersPointer; //this pointer is then returned
}
/* *************************************************************************************************
getMember function function requires an integer parameter input i, and in return it will return the
pointer to the holdings class stored at the integer i location with the library members vector
************************************************************************************************* */
Book* Library::getBook(int subscript){
    Book* holdingsPointer = &holdings[subscript]; //a pointer to a book is initialized to the address of the holdings subscript
    return holdingsPointer; //this pointer is then returned
}
/* *************************************************************************************************
the checkOutBook function is designed to allow a user to input the user ID and book ID numbers as
parameters. It then checks the status of the book to see if it can be checked out, and it the ID numbers
are valid the book is checked out to the user.
************************************************************************************************* */
void Library::checkOutBook(string patronID, string bookID){

    bool good_member = false; //good member bool initialized to false
    bool good_book = false; //good book bool initialized to false

    if (getLibrarySize() == 0) //to make sure a message appears if the library holds no books this if statement runs
        cout << "\nThis book ID is not recognized." << endl; //if no books are present, the ID cannot match any so this is stated
    if (getMembersSize() == 0) //to make sure a message appears if the library holds no members this statement runs
        cout << "\nThis member ID is not recognized." << endl; //if no members are present, the ID cannot match any so this is stated

    for (int i=0; i< getLibrarySize(); i++){ //this for loop scans through the contents of the holdings vector
        if (bookID == getBook(i)->getIdCode()){ //if the ID entered matches an ID in the library
            good_book = true; //then good book bool is set to true
            if (getBook(i)->getLocation() == CHECKED_OUT){ //if the book that matches the ID is checked out
                cout << "\nThis book has been checked out by another member."; //the user is informed it has been checked out
                for (int j=0; j< getMembersSize(); j++){
                    if (getPatron(j)->getIdNum() ==  patronID){ //a second check also confirms that the patron ID is good as well
                        good_member = true; //and sets this to true
                    }
                }
            }
            else if (getBook(i)->getLocation() == ON_HOLD){ //if the book of interest is on hold these actions occur
                cout << "\nThis book is on hold by another member at this time."; //the user is informed that it is currently on hold
                for (int j=0; j< getMembersSize(); j++){ //the for loop scans the contents of the library members
                    if (getPatron(j)->getIdNum() ==  patronID){ //if the ID matches that of an existing member
                        good_member = true; //good member bool is set to true
                    }
                }
            }
            else if (getBook(i)->getLocation() == ON_SHELF){ //if the book of interest is on the shelf
                for (int j=0; j< getMembersSize(); j++){ //the for loop scans the members of the library
                    if (getPatron(j)->getIdNum() ==  patronID){ //if the ID matches one of the members
                        good_member = true; //good member bool is set to true
                        getPatron(j)->getCheckedOutBooks().push_back(getBook(i)); //and the book is pushed back in to the member checkedoutbooks vector
                        getBook(i)->setLocation(CHECKED_OUT); //the location of the book is set to CHECKED_OUT
                        getBook(i)->setCheckedOutBy(getPatron(j)); //the person who checked out the book is updated
                        getBook(i)->setDateCheckedOut(getCurrentDate()); //the date the book was checked out was updated
                        cout << endl << getBook(i)->getTitle() << " successfully checked out to " << getPatron(j)->getName(); //the user is informed of these actions
                    }
                }
            }
        }
    }
    for (int i=0; i< getMembersSize(); i++){ //for loop to scan the members of the library in cases where a bad book ID is entered
        if (getPatron(i)->getIdNum() ==  patronID){ //checks the input ID against all patron IDs
            good_member = true; //this is set to true if it matches any of them
        }
    }
    if (good_member == false && getMembersSize() != 0) //if a bad member ID sets the flag to false and the members vector is >0
        cout << "\nThis member ID is not recognized."; //this is displayed
    if (good_book == false && getLibrarySize() != 0) //if a bad book ID sets the flag to false and the books vector is >0
        cout << "\nThis book ID is not recognized."; //this is displayed
}
/* *************************************************************************************************
requestBook function allows the user to enter patronID and bookID string variables as parameters. It
then determines if the book can be put on hold by a user, and if it can be the user is added as the
requestedBy to the book information
************************************************************************************************* */
void Library::requestBook(string patronID, string bookID){

    bool good_member = false; //good member bool initialized to false
    bool good_book = false; //good book bool initialized to true

    if (getLibrarySize() == 0) //if the library size is 0 the ID will not match any by default
        cout << "\nThis book ID is not recognized." << endl; //so this is displayed
    if (getMembersSize() == 0) //if the member size is 0 the ID will not match any by default
        cout << "\nThis member ID is not recognized." << endl; //so this is displayed

    for (int i=0; i< getLibrarySize(); i++){ //for loop scans the contents of the holdings vector
        if (getBook(i)->getIdCode() ==  bookID){ //if the book matches the ID of one of the books in the holdings vector
            good_book = true; //good book is set to true
            if (getBook(i)->getLocation() == ON_HOLD){ //if the book is already on hold
                cout << "\nThis book is on hold by another member at this time."; //the user is informed that they cannot put this book on hold
                for (int j=0; j< getMembersSize(); j++){ //for loop scans the members of the library
                    if (getPatron(j)->getIdNum() ==  patronID){ //if the patronID matches that of any member
                        good_member = true; //good member bool is set to true
                    }
                }
            }
            else if (getBook(i)->getLocation() == CHECKED_OUT){ //if the book is designated as checked out
                for (int j=0; j< getMembersSize(); j++){ //the for loop scans the members vector
                    if (getPatron(j)->getIdNum() ==  patronID){ //if the patron ID matches one in the members vector
                        if (patronID == getBook(i)->getCheckedOutBy()->getIdNum()) //a second check prevents a user who has checked out the book from also requesting it on hold
                            cout << "\nYou cannot reserve a book you already have checked out."; //and they are informed of this
                            good_member = true; //good member is set to true
                        else{ //if the user is not currently holding the book, but it is checked out
                        good_member = true; //good member is set to true
                        getBook(i)->setRequestedBy(getPatron(j)); //requested by is updated
                        getBook(i)->setLocation(ON_HOLD); //the book is then placed ON_HOLD
                        cout << endl << getBook(i)->getTitle() << " placed on hold for " << getPatron(j)->getName(); //user is informed of these actions
                        }
                    }
                }
            }
        }
    }
    for (int i=0; i< getMembersSize(); i++){ //in case bad book ID entered, this for loop scans the user IDs of the library
        if (getPatron(i)->getIdNum() ==  patronID){ //if the entered ID matches any of the ones in the member vector
            good_member = true; //good member is set to true
        }
    }
    if (good_member == false && getMembersSize() != 0) //as long as good member is false and there are more than 0 members
        cout << "\nThis member ID is not recognized."; //this is displayed
    if (good_book == false && getLibrarySize() != 0) //as long as good book is false and there are more than 0 books
        cout << "\nThis book ID is not recognized."; //this is displayed
}
/* *************************************************************************************************
the returnBook function allows a user who has checked out a book to return it to the library, removing
it from their account. If another user has requested it it will automatically be checked out to them
at this point in time. Only a bookID is required as a parameter to this function.
************************************************************************************************* */
void Library::returnBook(string bookID){

    bool good_book = false; //good book bool set to false

    if (getLibrarySize() == 0) //if the size of the library is 0
        cout << "\nThis book ID is not recognized." << endl; //this is displayed as the ID cannot match any IDs

    for (int i=0; i< getLibrarySize(); i++){ //for loop scans the books of the library
        if (getBook(i)->getIdCode() ==  bookID){ //if the entered ID matches one in the library
            good_book = true; //good book is set to true
            if (getBook(i)->getLocation() == 0) //if the book is currently ON_SHELF
                cout << "\nThis book has already been checked back in."; //user is informed it is already on the shelf
            if (getBook(i)->getLocation() == 2){ //if the book is currently CHECKED_OUT
                getBook(i)->setLocation(ON_SHELF); //it is then set to ON_SHELF
                getBook(i)->getCheckedOutBy()->removeBook(getBook(i)); //the book is removed from the user's inventory
                getBook(i)->setCheckedOutBy(NULL); //the set checked out is returned to NULL
                cout << "\nBook successfully returned."; //user is informed of this
            }
            if (getBook(i)->getLocation() == 1){ //if the book is ON_HOLD
                getBook(i)->getCheckedOutBy()->removeBook(getBook(i)); //book is removed from first user's inventory
                getBook(i)->getRequestedBy()->addBook(getBook(i)); //book is added to new user's inventory
                getBook(i)->setCheckedOutBy(getBook(i)->getRequestedBy()); //set checked out by is updated to reflect this change
                getBook(i)->setRequestedBy(NULL); //set requested by is set to NULL
                getBook(i)->setLocation(CHECKED_OUT); //location is checked to CHECKED_OUT
                getBook(i)->setDateCheckedOut(getCurrentDate()); //the current date is set to the date of checkout for the new user
                cout << "\nBook returned, and checked out to " << getBook(i)->getCheckedOutBy()->getName(); //user is informed of these changes
            }
        }
    }
    if (good_book == false && getLibrarySize() != 0) //if good book flag has been set to false and the library size is >0 then
        cout << "\nThe book ID is not recognized"; //this is displayed
}
/* *************************************************************************************************
the payFine function allows the user to enter a double amount, so the function itself takes a patron
ID and double variable as parameters. It this updates their fine by removing said double amount from
their dues.
************************************************************************************************* */
void Library::payFine(string patronID, double payment){

    bool good_member = false; //good member is initialized to false

    for (int i=0; i< getMembersSize(); i++){ //for loop scans the contents of the members vector
        if (getPatron(i)->getIdNum() ==  patronID){ //if the ID matches that of an existing member
            good_member = true; //good member is set to true
            getPatron(i)->amendFine(payment*-1); //the payment amount is passed to the amendFine function to update it's amount
            cout << fixed << setprecision(2)<< showpoint; //output is formatted
            cout << "New balance is: $" << getPatron(i)->getFineAmount(); //user is informed of their new balance
        }
    }
    if (good_member == false) //if good member bool flag is set to false
        cout << "\nMember ID not recognized."; //they are informed that the ID was not valid
}
/* *************************************************************************************************
The viewBookInfo function is designed to give the user any and all information available out any given
book in the library, it takes the book ID string as its parameter.
************************************************************************************************* */
void Library::viewBookInfo(string bookID){

    bool good_book = false; //good book is initialized to false.

    if (getLibrarySize() == 0) //if the library size is 0
        cout << "\nBook ID not recognized." << endl; //by default the IDs will not match so this is displayed

    for (int i=0; i< getLibrarySize(); i++){ //for loop scans the holdings vector
        if (getBook(i)->getIdCode() ==  bookID){ //if the ID matches that of one in the library

            good_book = true; //good book is set to true

            cout << endl << getBook(i)->getTitle() << endl; //title is printed
            cout << "by " << getBook(i)->getAuthor() << endl << endl; //author is printed

            //location is printed
            if (getBook(i)->getLocation() == 0)
                cout << "Book is on the shelf." << endl;
            if (getBook(i)->getLocation() == 2)
                cout << "Book is checked out." << endl;
            if (getBook(i)->getLocation() == 1)
                cout << "Book is on hold." << endl;

            if(getBook(i)->getLocation() != 0) //if the book is not in the shelf
            cout << "Checked out by " << getBook(i)->getCheckedOutBy()->getName() << endl; //the person who checked it out is printed
            if(getBook(i)->getLocation() == 1) //if the book is on hold
            cout << "Reserved by " << getBook(i)->getRequestedBy()->getName() << endl; //the person who requested it is printed
            if(getBook(i)->getLocation() != 0) //if the book is not on the shelf
            cout << "Checked out on day " << getBook(i)->getDateCheckedOut() << endl; //the date it was checked out is printed
        }
    }
    if (good_book == false && getLibrarySize() != 0) //if the good book bool flag is set to false and the library size is >)
        cout << "\nThe book ID is not recognized"; //this informs the user the ID is not recognized
}
/* *************************************************************************************************
The viewPatronInfo function is designed for the user to enter a patronID string as a parameter and it
returns both the patron ID and their name, as well as any books they currently have checked out.
************************************************************************************************* */
void Library::viewPatronInfo(string patronID){

    bool good_member = false; //good member is initialized to false

    if (getMembersSize() == 0) //if the number of members in the library is equal to 0
        cout << "\nMember ID not recognized." << endl; //this is displayed

    for (int i=0; i< getMembersSize(); i++){ //for loop scans the contents of the members vector
        if (getPatron(i)->getIdNum() ==  patronID){ //if the ID matches one within the members vector
            good_member = true; //good member is set to true

            cout << endl << getPatron(i)->getName() << endl << endl; //patron name is printed
            cout << fixed << showpoint << setprecision(2); //data is formatted
            cout << "Current balance $" << getPatron(i)->getFineAmount() << endl; //the current balance is printed
            cout << "Current books checked out: " << endl << endl; //list of current books the user has

            for (int j=0; j< getLibrarySize(); j++){ //for loop scans the contents of the library
                if (getBook(j)->getCheckedOutBy() == getPatron(i)) //if the books checked out by value is equal to the patron
                    cout << getBook(j)->getTitle() << endl; //then the title is printed on the list they checked out
            }
        }
    }
    if (good_member == false) //if good member is set to false
        cout << "\nMember ID not recognized."; //user is informed ID is not recognized.
}
