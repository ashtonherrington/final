#include <iostream> //header file for input output stream header file
#include "Patron.h" //include the Patron header file
#include "Library.h" //include the Library header file
#include "Book.h" //include the Book header file
#include <vector> //include the header file for the user of vectors
#include <stdio.h> //include the stdio.h header file
#include <iomanip> //include the header file for formatting output
#include <limits> //include the header file for use of numeric limits
#include <cstdlib> //include the header file for the cstandard library

using namespace std; //declare use of standard namespace

int user_menu(Library& the_library); //function prototype for user_menu function
void add_book(Library& the_library); //function prototype for add_book function
void add_member(Library &the_library); //function prototype for add_member function
void list_holdings(Library& the_library); //function prototype for list_holdings function
void list_members(Library& the_library); //function prototype for list_members function
void increment_date(Library &the_library); //function prototype for increment_date function
int display_date(Library &the_library); //function prototype for display_date function
void book_checkout(Library &the_library); //function prototype for book_checkout function
void book_reserve(Library &the_library); //function prototype for book_reserve function
void book_info(Library &the_library); //function prototype for book_info function
void member_info(Library &the_library); //function prototype for member_info function
void return_book(Library &the_library); //function prototype for return_book function
void pay_fines(Library &the_library); //function prototype for pay_fines function

int main(){

    Library the_library; //object of the Library class named the_library is created

    int selection; //integer to hold the return value from the user_menu function

    do{ //loop that encompasses enter program unless the user chooses the quit options

        selection = user_menu(the_library); //selection int is set equal to return value from user_menu() function

        switch(selection){ //switch statement under the control of the selection

            case 1:
                list_holdings(the_library); //menu choice of 1 runs list_holdings function
                break;
            case 2:
                list_members(the_library); //menu choice of 2 runs list_members function
                break;
            case 3:
                add_book(the_library); //menu choice of 3 runs add_book function
                break;
            case 4:
                add_member(the_library); //menu choice of 4 runs add_member function
                break;
            case 5:
                display_date(the_library); //menu choice of 5 runs display_date function
                break;
            case 6:
                increment_date(the_library); //menu choice of 6 displays increment_date function
                break;
            case 7:
                book_checkout(the_library); //menu choice of 7 displays book_checkout function
                break;
            case 8:
                book_reserve(the_library); //menu choice of 8 displays book_reserve function
                break;
            case 9:
                member_info(the_library); //menu choice of 9 displays the member_info function
                break;
            case 10:
                book_info(the_library); //menu choice of 10 displays the book_info function
                break;
            case 11:
                return_book(the_library); //menu choice of 11 displays the return_book function
                break;
            case 12:
                pay_fines(the_library); //menu choice of 12 displays the pay_fines function
                break;
            case 13:
                cout << "\nDonna Noble has left the library, Donna Noble has been saved." << endl; //Dr. Who Joke
                cout << "\n\nPress enter to continue."; //user is prompted to hit enter to continue
                cin.get(); //
                break;

        }


        cout << string(100, '\n'); //screen is cleared

    }while(selection != 14); // ends the program if user chooses 14

    return 0;
}
/* *******************************************************************************************
user_menu is designed to prompt the user for 4 options. Based on which option they choose this
function returns the value of user_selection which is passed to the int "selection". This in turn
decides which of the other functions are called within the program. This function is called after
every other function runs allowing the user new prompts.
******************************************************************************************* */
int user_menu(Library& the_library){

    int user_selection = 0; //user_selection is locally initialized every time this function runs

    //the below menu choices are then prompted to the user
    cout << "Welcome Library User! (DAY " << the_library.getCurrentDate() << ")";
    cout << "\n\n1.  List books held by library.";
    cout << "\n2.  List library members.";
    cout << "\n3.  Add new book to the library.";
    cout << "\n4.  Add new member to the library.";
    cout << "\n5.  View current date.";
    cout << "\n6.  Increment current date.";
    cout << "\n7.  Check out book.";
    cout << "\n8.  Request hold on book.";
    cout << "\n9.  View member information.";
    cout << "\n10. View book information.";
    cout << "\n11. Return book.";
    cout << "\n12. Pay fines.";
    cout << "\n13. Save Donna Noble.";
    cout << "\n14. Quit.";
    cout << "\n\nPlease choose your selection now: ";

    //Input validation insures that the user only chooses an integer between 1 and 14
    while(!(cin>>user_selection) || user_selection < 1 || user_selection > 14){
        cin.clear(); //failbit flag cleared
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); //input buffer cleared
        cout << "Please enter a choice between 1 and 14: "; //prompt for new input
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); //keyboard buffer cleared after good input

    return user_selection; //function returns user_selection
}
/* *******************************************************************************************
list_holdings function is designed to display the entire collection of books held by the library
at any given time. Uses a Library object as a parameter.
******************************************************************************************* */
void list_holdings(Library& the_library){

    if (the_library.getLibrarySize() == 0) //if library has 0 books
        cout << "\n\nThere are currently no books in the library."; //this is displayed

    cout << string(1, '\n');

    for (int i=0; i< the_library.getLibrarySize(); i++){ //for loop scans the books in the library
        cout << "ID#: " << the_library.getBook(i)->getIdCode(); //displayed each ID
        cout << "   " << the_library.getBook(i)->getTitle() << endl; //with each title
        cout << "by " << the_library.getBook(i)->getAuthor() << endl << endl; //and each author
    }
    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
list_members function is designed to display the entire collection of members of the library
at any given time. Uses a Library object as a parameter.
******************************************************************************************* */
void list_members(Library& the_library){

    if (the_library.getMembersSize() == 0) //if library has 0 members
        cout << "\n\nThere are currently no members in the library."; //this is displayed

    cout << string(1, '\n');

    for (int i=0; i< the_library.getMembersSize(); i++){ //for loop scans the members vector
        cout << "MemID#: " << the_library.getPatron(i)->getIdNum(); //and displays member IDs
        cout << "   " << the_library.getPatron(i)->getName() << endl << endl; //and their names
    }
    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
add_book function is designed to let the user enter requisite information about a new book and
then the new book is added to the existing pool of library books. Uses a Library object as a
parameter.
******************************************************************************************* */
void add_book(Library &the_library){
    the_library.addBook(); //the_library addBook function is called
}
/* *******************************************************************************************
add_member function is designed to let the user enter requisite information about a new member
and then the new member is added to the existing pool of library members.
******************************************************************************************* */
void add_member(Library &the_library){
    the_library.addMember(); //the_library addMember function is called
}
/* *******************************************************************************************
display_date function is designed to inform user of current date. Uses a Library object as a
parameter.
******************************************************************************************* */
int display_date(Library &the_library){
    cout << "\nThe current date is " << the_library.getCurrentDate(); //current date displayed to the user

    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
increment_date function is designed to allow user to increment date one day at a time. Uses a
Library object as a parameter.
******************************************************************************************* */
void increment_date(Library &the_library){

    the_library.incrementCurrentDate(); //date increment is called

    cout << "\nDate incremented." << endl; //user is informed this occurs
    cout << "\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
book_checkout function is designed to allow users to check out books from the shelf as long as
they are not already checked out or on hold by other users. Uses a Library object as a parameter.
******************************************************************************************* */
void book_checkout(Library &the_library){
    cout << "\nPlease enter the book ID you are interested in checking out: "; //user is prompted to enter book ID

    string temp_book_id; //temp string to hold said book ID
    getline (cin, temp_book_id); //it is saved by getline

    cout << "Please enter the member ID of the member wanting to check out this book: "; //user is prompted to enter member ID

    string temp_member_id; //temp string to hold said member ID
    getline (cin, temp_member_id); //it is saved by getline

    the_library.checkOutBook(temp_member_id, temp_book_id); //the_library checkOutBook function is called with member and book ID as parameters

    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
book_reserve function is designed to allow users to put a book already reserved by another user
on hold for when it arrived back in to the library. Uses a Library object as a parameter.
******************************************************************************************* */
void book_reserve(Library &the_library){
    cout << "\nPlease enter the book ID you are interested in checking out: "; //user is prompted to enter book ID

    string temp_book_id; //temp string to hold said book ID
    getline (cin, temp_book_id); //it is saved by getline

    cout << "Please enter the member ID of the member wanting to check out this book: "; //user is prompted to enter member ID

    string temp_member_id; //temp string to hold said member ID
    getline (cin, temp_member_id); //it is saved by getline

    the_library.requestBook(temp_member_id, temp_book_id);//the_library requestBook function is called with member and book ID as parameters

    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
The book_info function requests a book ID, and displays all the known information the library
has on said book. It uses a Library object as a parameter.
******************************************************************************************* */
void book_info(Library &the_library){

    cout << "\nPlease enter the book ID you are interested in checking out: "; //user is prompted to enter book ID

    string temp_book_id; //temp string to hold said book ID
    getline (cin, temp_book_id); //it is saved by getline

    the_library.viewBookInfo(temp_book_id); //the_library viewBookInfo function is called with book ID as parameter

    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
The member_info function requests the user for a member ID, it then displays all the known
information about that library member to the user. It uses a Library object as a parameter.
******************************************************************************************* */
void member_info(Library &the_library){

    cout << "\nPlease enter the member ID you wish to view: "; //user is prompted to enter a member ID

    string temp_member_id; //temp member ID string declared to store the ID
    getline (cin, temp_member_id); //getline saves the enter string

    the_library.viewPatronInfo(temp_member_id); //the_library viewPatronInfo function is called with the temp member ID as parameter

    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
/* *******************************************************************************************
the return_book function is designed to ask the user for a book ID, and then returns it to
the library, if another user has requested it on hold, it automatically assigns the book to the
new user. It uses a Library object as a parameter.
******************************************************************************************* */
void return_book(Library &the_library){

    cout << "\nPlease enter the book ID you wish to return: "; //user is prompted to enter the book ID

    string temp_book_id; //temp string variable declared to hold their input
    getline (cin, temp_book_id); //getline acquires the user input in to this string

    the_library.returnBook(temp_book_id); //the_library returnBook function is called using the string as a parameter

    cout << "\n\nPress enter to continue."; //user is prompted to continue
    cin.get();
}
/* *******************************************************************************************
The pay_fines function is designed to allow a user to enter their member ID. It then asks for
an amount they wish to pay and updates their account to reflect the dues they have paid. It uses
a Library object as a parameter.
******************************************************************************************* */
void pay_fines(Library &the_library){

    cout << "\nPlease enter the member ID: "; //user is prompted to enter a member ID

    string temp_member_id; //string variable declared to hold this ID
    getline (cin, temp_member_id); //user input is stored in this string variable by getline

    cout << "\nPlease enter a payment amount: "; //user is prompted to enter a payment amount
    double temp_payment; //double is declared to hold this payment amount
    while (!(cin >> temp_payment || temp_payment < 0.0)){ //while loop ensure the amount the user pays is a double and above 0
        cin.clear(); //failbit flag cleared
        cin.ignore(1000, '\n'); //input buffed cleared
        cout << "\nPlease enter a payment amount in numbers only: "; //user is prompted for good input
    }

    the_library.payFine(temp_member_id, temp_payment); //the_library function payFine called with the member ID and payment amount as parameters
    cin.ignore(1000,'\n'); //input buffer is cleared
    cout << "\n\nPress enter to continue."; //prompt to continue
    cin.get();
}
