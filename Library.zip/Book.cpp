#include "Book.h" //include the Book header file

/* *************************************************************************************************
The default constructor for the Book class
************************************************************************************************* */
Book::Book(){
}
}
/* *************************************************************************************************
The alterative constructor in which book class is created with the input of three string parameters
for the ID code, title and author
************************************************************************************************* */
Book::Book(std::string idc, std::string t, std::string a){
    idCode = idc;
    title = t;
    author = a;
    checkedOutBy = NULL;
    requestedBy = NULL;
    location = ON_SHELF;
    dateCheckedOut = NULL;
}
/* *************************************************************************************************
getIdCode function is designed to give user access to the idCode variable
************************************************************************************************* */
std::string Book::getIdCode(){
    return idCode;
}
/* *************************************************************************************************
getTitle unction is designed to give user access to the title variable
************************************************************************************************* */
std::string Book::getTitle(){
    return title;
}
/* *************************************************************************************************
getAuthor function is designed to give user access to the author variable
************************************************************************************************* */
std::string Book::getAuthor(){
    return author;
}
/* *************************************************************************************************
getLocation function is designed to give user access to the location variable
************************************************************************************************* */
Locale Book::getLocation(){
    return location;
}
/* *************************************************************************************************
setLocation function is designed to take a parameter of a Locale and update the locale of the book
to be the same as the parameter.
************************************************************************************************* */
void Book::setLocation(Locale lo){
    location = lo;
}
/* *************************************************************************************************
getCheckedOutBy function is designed to give the user access to the pointer to the patron who
checked out the book
************************************************************************************************* */
Patron* Book::getCheckedOutBy(){
    return checkedOutBy;
}
/* *************************************************************************************************
setCheckedOutby function is designed to accept a pointer to a patron as a parameter (say that five times
fast) and set the RequestedBy of the book equal to it
************************************************************************************************* */
void Book::setCheckedOutBy(Patron* p){
    checkedOutBy = p;
}
/* *************************************************************************************************
getRequestedBy function is designed to give the user access to the pointer to the patron who requested
the book
************************************************************************************************* */
Patron* Book::getRequestedBy(){
    return requestedBy;
}
/* *************************************************************************************************
setRequestedBy function is designed to accept a pointer to a patron as a parameter (say that five times
fast) and set the RequestedBy of the book equal to it
************************************************************************************************* */
void Book::setRequestedBy(Patron* p){
    requestedBy = p;
}
/* *************************************************************************************************
getDateCheckedOut function is designed to give the user access to the dateCheckedOut integer
************************************************************************************************* */
int Book::getDateCheckedOut(){
    return dateCheckedOut;
}
/* *************************************************************************************************
setDateCheckedOut is designed to accept an integer parameter, and then set the dateCheckedOut of the
book equal to it.
************************************************************************************************* */
void Book::setDateCheckedOut(int d){
    dateCheckedOut = d;
}
