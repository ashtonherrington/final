#include "Patron.h" //include the Patron header file
#include "Library.h" //include the Library header file

/* *************************************************************************************************
The default constructor for the Patron class initializes fine amount to 0.0 and reserves the
checkOutBooks vector to 100
************************************************************************************************* */
Patron::Patron(){
    fineAmount = 0.0;
    checkedOutBooks.reserve(100);
}
/* *************************************************************************************************
The alternative constructor for the Patron class initializes fine amount to 0.0 and reserves the
checkOutBooks vector to 100. It also accepts two string parameters which it then sets equal to the ID
code of the patron and the patron name
************************************************************************************************* */
Patron::Patron(string idn, string n){
    idNum = idn;
    name = n;
    fineAmount = 0.0;
    checkedOutBooks.reserve(100);
}
/* *************************************************************************************************
getIdNum function is designed to give the user access to the idNum string
************************************************************************************************* */
string Patron::getIdNum(){
    return idNum;
}
/* *************************************************************************************************
getName function is designed to give the user access to the name string
************************************************************************************************* */
string Patron::getName(){
    return name;
}
/* *************************************************************************************************
getCheckedOutBooks function is designed to give the user access to the vector of pointers checkedOutBooks
************************************************************************************************* */
std::vector<Book*> Patron::getCheckedOutBooks(){
    return checkedOutBooks;
}
/* *************************************************************************************************
addBooks function is designed to accept a pointer to a book ad then push it back to the checkedOutBooks
vector
************************************************************************************************* */
void Patron::addBook(Book* b){
    checkedOutBooks.push_back(b);
}
/* *************************************************************************************************
removeBook function is designed to accept a pointer to a book as a parameter. It then scans the users
checked out books and if they are holding that book it removes the book at that location within their
checkedoutbooks vector
************************************************************************************************* */
void Patron::removeBook(Book* b){
    for (int i=0; i<checkedOutBooksLength(); i++){ //for loop scans the user's books
        if (checkedOutBooks[i] == b) //if any of those books match the book input as the parameter
        checkedOutBooks.erase(checkedOutBooks.begin()+i); //the erase function moves i over and erases that book
    }
}
/* *************************************************************************************************
the getFineAmount function is designed to give the user access to the double variable fineAmount
************************************************************************************************* */
double Patron::getFineAmount(){
    return fineAmount;
}
/* *************************************************************************************************
the amendFine function is designed to accept a double as a parameter and then add that amount to the
fine *should have been -=, but it is multiplied by -1 later to fix this
************************************************************************************************* */
void Patron::amendFine(double amount){
    fineAmount += amount;
}
/* *************************************************************************************************
the checkedOutBooksLength function is designed to quickly allow the user access to the size of the
checkedOutBooks vector.
************************************************************************************************* */
int Patron::checkedOutBooksLength(){
    return checkedOutBooks.size();
}
