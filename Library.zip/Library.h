//
//  Library.h
//  examples
//
//  Created by Tim Alcon on 11/25/14.
//  Copyright (c) 2014 Tim Alcon. All rights reserved.
//

#ifndef __examples__Library__
#define __examples__Library__

#include <vector>
#include <stdio.h>
#include <string>
#include <iostream>
#include <iomanip>

class Patron;
class Book;

using namespace std;

class Library
{
private:
    vector<Book> holdings;
    vector<Patron> members;
    int currentDate;
    int librarySize;
    int membersSize;

public:

    static const double DAILY_FINE = 0.1;
    Library();
    void addBook();
    void addMember();
    void checkOutBook(string patronID, string bookID);
    void returnBook(string bookID);
    void requestBook(string patronID, string bookID);
    void incrementCurrentDate();
    int getCurrentDate();
    void payFine(string patronID, double payment);
    void viewPatronInfo(string patronID);
    void viewBookInfo(string bookID);
    int getLibrarySize();
    int getMembersSize();
    Patron* getPatron(int subscript);
    Book* getBook(int subscript);
};

#endif /* defined(__examples__Library__) */
